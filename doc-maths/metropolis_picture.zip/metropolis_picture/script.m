% But de ce script : utiliser la m?thode de Metropolis-Hasting pour
% approcher une loi de probabilit? "donn?e" par une image en noir et
% blanc...

figure(1); clf;
figure(2); clf;

%% Temperature tres elevee : marche aleatoire sans contrainte

figure(1)
IM=imread('lena.png');
imagesc(IM,[0,255]);
colormap gray;
axis image;

pic=imread('lena.png');
L=500; %time
M=1000; %number of particles
T=1000; %temperature
markov_picture_T(pic,L,M,'neighbor',T);

% 2 options : 'neighbor'--> marche al?atoire istotrope
%             'uniform'--> points choisis uniform?ment ind?pendamment


%% Temperature tres faible : beaucoup de contrainte, on explore tres peu
% l'espace

figure(1)
IM=imread('lena.png');
imagesc(IM,[0,255]);
colormap gray;
axis image;

pic=imread('lena.png');
L=1000; %time
M=1000; %number of particles
T=1; %temperature
markov_picture_T(pic,L,M,'neighbor',T);

%% Temperature raisonnable : on explore suffisamment l'espace tout en
% respectant les contraintes de metropolis

figure(1)
IM=imread('lena.png');
imagesc(IM,[0,255]);
colormap gray;
axis image;

pic=imread('lena.png');
L=1000; %time
M=1000; %number of particles
T=10; %temperature
markov_picture_T(pic,L,M,'neighbor',T);

%% L'id?el, c'est de rediger une fonction similaire qui effectue un "recuit" : 
% on fait decroitre progressivement la temperature au cours du temps...

