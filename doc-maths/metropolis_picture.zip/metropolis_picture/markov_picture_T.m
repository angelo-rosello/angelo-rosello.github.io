function markov_picture_T(pic,L,M,option,T)
%pic = the picture, L= length of the process, 
%M=number of particles %T=temperature;

%Initializa
N=length(pic);
X=randi(N,1,2*M); %X=[x_1,y_1,x_2,y_2,...]

P=exp(-(255-double(pic))./T);

%Generate and print the images
figure(2);
clf;
A=pic_matrix(N,X);
imagesc(A,[0,255]);
colormap gray;
axis image;
for l=2:L
   X=metropolis_update(X,N,P,option);
   B=pic_matrix(N,X);
   A=A+B;
   imagesc((1/sqrt(l))*A,[0,255]);
   colormap gray;
   axis image;
   title(['Particles : ',num2str(M),', Temperature : ',num2str(T),', Time : ',num2str(l)])
   drawnow;
end
end

function B=pic_matrix(N,Y) %pixels where the particles are
M=size(Y); M=M(2); M=M/2; %number of particles
B=zeros(N);
for m=1:M
   B(Y(2*m-1),Y(2*m))=255; 
end
end


function Y=metropolis_update(X,N,P,option) % apply the metropolis algorithm
% N=size of the image, P=invariant proba
% option=[uniform or neighbor]
M=size(X); M=M(2); M=M/2; %number of particles
Y=zeros(1,2*M);
for m=1:M
    x=X(2*m-1); y=X(2*m);
   if (strcmp(option,'uniform'))
       x1=randi(N);
       y1=randi(N);
   else
       [x1,y1]=neighbor(x,y,N);
   end
   p=min([1,P(x1,y1)/P(x,y)]);
   if (rand()<=p)
       Y(2*m-1)=x1; Y(2*m)=y1;
   else
       Y(2*m-1)=x; Y(2*m)=y;
   end
    
end
end

function [x,y]=neighbor(X,Y,N)
    n=randi(4);
    e=(n==1).*[0,1]+(n==2).*[0,-1]+(n==3).*[1,0]+(n==4).*[-1,0];
    x=X+e(1); 
    if (x==N+1) 
        x=1; 
    end
    if (x==0) 
       x=N; 
    end
    y=Y+e(2); 
    if (y==N+1) 
        y=1; 
    end
    if (y==0) 
       y=N; 
    end
end

