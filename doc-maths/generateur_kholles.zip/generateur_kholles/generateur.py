# -*- coding: utf-8 -*-
"""
GENERATEUR DE PLANNING DE KHOLLES V6

"""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Tuple

from ortools.sat.python import cp_model
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo


# ============================================================
# CONFIGURATION
# ============================================================

GROUPES: List[int] = []
NOMBRE_SEMAINES = 0

# Les matières sont importées depuis « Alternance des matières ».
# L’ordre est celui de leur première apparition dans cette feuille.
MATIERES: List[str] = []
MATIERE_RANG: Dict[str, int] = {}
CYCLE_ALTERNANCE = 0

DUREE_COLLE_MINUTES = 60
BATTEMENT_SOUHAITE_MINUTES = 30

MAX_COLLES_PAR_JOUR = 2

TEMPS_MAX_SOLVEUR = 60
SEED_SOLVEUR = 42

# Poids des objectifs de roulement. (Renseignés dans la feuille "Paramètres" du fichier input)

POIDS = {}

PARAMETRES_ATTENDUS = [
    "colleur_jamais_vu",
    "desequilibre_colleur",
    "repetition_colleur_consecutif",
    "repetition_colleur_proche",
    "desequilibre_creneau",
    "repetition_creneau_consecutif",
    "enchainement_colles",
    "deux_colles_meme_jour",
    "equilibre_deux_colles_meme_jour",
    "ecart_max_min_deux_colles_meme_jour",
]


FICHIER_SORTIE = "output.xlsx"


# ============================================================
# DONNÉES IMPORTÉES DEPUIS INPUT.XLSX
# ============================================================
#
# Le fichier doit être placé dans le même dossier que ce programme.

FICHIER_CONFIGURATION = "input.xlsx"

GROUPES: List[int] = []
NOMBRE_SEMAINES = 0
ALTERNANCE: Dict[int, List[List[str]]] = {}
CONTRAINTES_HORAIRES: Dict[int, List[Tuple[str, int, int]]] = {}


# ============================================================
# CRENEAUX
# ============================================================

@dataclass(frozen=True)
class Creneau:
    matiere: str
    jour: str
    heure: str
    minutes: int
    colleur: str
    semaines_disponibles: Tuple[int, ...]


def heure_en_minutes(heure: str) -> int:
    h, m = heure.split(":")
    return int(h) * 60 + int(m)


def normaliser_heure(valeur) -> str:
    """Convertit une heure Excel ou une chaîne en HH:MM."""
    if hasattr(valeur, "hour") and hasattr(valeur, "minute"):
        return f"{valeur.hour:02d}:{valeur.minute:02d}"

    texte = str(valeur).strip().lower()
    if re.fullmatch(r"\d{1,2}h\d{0,2}", texte):
        texte = texte.replace("h", ":")
        if texte.endswith(":"):
            texte += "00"
    if not texte:
        raise ValueError("Heure vide.")

    # Accepte notamment 8:30, 08:30, 8h30, 08h30.
    texte = texte.lower().replace("h", ":")
    if ":" not in texte:
        raise ValueError(f"Format d'heure inconnu : '{valeur}'")

    morceaux = texte.split(":")
    if len(morceaux) != 2:
        raise ValueError(f"Format d'heure inconnu : '{valeur}'")

    return f"{int(morceaux[0]):02d}:{int(morceaux[1]):02d}"


def creer_creneau(
    matiere: str,
    jour: str,
    heure: str,
    colleur: str,
    semaines_disponibles=None,
) -> Creneau:
    if semaines_disponibles is None:
        semaines_disponibles = tuple(range(1, NOMBRE_SEMAINES + 1))
    else:
        semaines_disponibles = tuple(semaines_disponibles)

    return Creneau(
        matiere=matiere,
        jour=jour,
        heure=heure,
        minutes=heure_en_minutes(heure),
        colleur=colleur,
        semaines_disponibles=semaines_disponibles,
    )


JOURS_ORDRE = {
    "Lundi": 0,
    "Mardi": 1,
    "Mercredi": 2,
    "Jeudi": 3,
    "Vendredi": 4,
}


def heure_contrainte_en_minutes(valeur, valeur_par_defaut: int) -> int:
    if valeur is None or str(valeur).strip() == "":
        return valeur_par_defaut
    return heure_en_minutes(normaliser_heure(valeur))


def creneau_interdit_pour_groupe(groupe: int, creneau: Creneau) -> bool:
    """Vrai si le créneau de 60 min recouvre une plage interdite."""
    for jour, debut, fin in CONTRAINTES_HORAIRES.get(groupe, []):
        if creneau.jour != jour:
            continue
        debut_colle = creneau.minutes
        fin_colle = creneau.minutes + DUREE_COLLE_MINUTES
        if max(debut_colle, debut) < min(fin_colle, fin):
            return True
    return False


def charger_configuration_excel(fichier: str = FICHIER_CONFIGURATION) -> None:
 
    global GROUPES, NOMBRE_SEMAINES, ALTERNANCE, CRENEAUX, CYCLE_ALTERNANCE, CONTRAINTES_HORAIRES

    chemin = Path(fichier)
    if not chemin.exists():
        raise FileNotFoundError(
            f"Fichier de configuration introuvable : {chemin.resolve()}\n"
            f"Le fichier '{fichier}' doit être dans le même dossier que le programme."
        )

    try:
        wb = load_workbook(chemin, data_only=True)
    except Exception as exc:
        raise ValueError(
            f"Impossible de lire le fichier Excel '{fichier}' : {exc}"
        ) from exc


    # --------------------------------------------------------
    # Feuille 4 : paramètres
    # --------------------------------------------------------
    ws_param = wb["Paramètres"]

    if ws_param.max_column < 2:
        raise ValueError(
            "La feuille 'Paramètres' doit contenir au moins "
            "les colonnes 'Paramètres' et 'Valeur'."
        )

    en_tete_param = str(ws_param.cell(1, 1).value).strip().lower()
    en_tete_valeur = str(ws_param.cell(1, 2).value).strip().lower()

    if en_tete_param != "paramètres" or en_tete_valeur != "valeur":
        raise ValueError(
            "La feuille 'Paramètres' doit commencer par les colonnes "
            "'Paramètres' et 'Valeur'."
        )

    poids_lus = {}

    for ligne in range(2, ws_param.max_row + 1):
        nom_valeur = ws_param.cell(ligne, 1).value

        if nom_valeur is None or str(nom_valeur).strip() == "":
            continue

        nom = str(nom_valeur).strip()

        if nom not in PARAMETRES_ATTENDUS:
            raise ValueError(
                f"Ligne {ligne} de 'Paramètres' : paramètre inconnu "
                f"'{nom}'."
            )

        valeur = ws_param.cell(ligne, 2).value

        if valeur is None or isinstance(valeur, bool):
            raise ValueError(
                f"Ligne {ligne} de 'Paramètres' : la valeur de "
                f"'{nom}' est vide ou invalide."
            )

        try:
            nombre = float(valeur)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"Ligne {ligne} de 'Paramètres' : valeur non numérique "
                f"pour '{nom}' : {valeur!r}."
            ) from exc

        if nombre < 0:
            raise ValueError(
                f"Ligne {ligne} de 'Paramètres' : la pondération "
                f"'{nom}' ne peut pas être négative."
            )

        poids_lus[nom] = int(nombre) if nombre.is_integer() else nombre

    parametres_manquants = [
        nom for nom in PARAMETRES_ATTENDUS if nom not in poids_lus
    ]

    if parametres_manquants:
        raise ValueError(
            "Paramètres manquants ou sans valeur dans la feuille "
            "'Paramètres' : " + ", ".join(parametres_manquants)
        )

    POIDS.clear()
    POIDS.update(poids_lus)


    noms_attendus = ["Créneaux de kholles", "Alternance des matières"]
    for nom in noms_attendus:
        if nom not in wb.sheetnames:
            raise ValueError(
                f"La feuille '{nom}' est absente de '{fichier}'. "
                f"Feuilles trouvées : {wb.sheetnames}"
            )

    # --------------------------------------------------------
    # Feuille 1 : créneaux
    # --------------------------------------------------------
    ws = wb["Créneaux de kholles"]
    headers = [ws.cell(1, col).value for col in range(1, ws.max_column + 1)]

    if len(headers) < 5:
        raise ValueError(
            "La feuille 'Créneaux de kholles' doit contenir au moins "
            "Matière, Colleur, Jour, Heure et une colonne de semaine."
        )

    def verifier_entete(obtenu, attendu):
        return str(obtenu).strip().lower() == attendu.lower()

    entetes_base = ["Matière", "Colleur", "Jour", "Heure"]
    for i, attendu in enumerate(entetes_base, start=1):
        if not verifier_entete(headers[i - 1], attendu):
            raise ValueError(
                f"Colonne {i} de 'Créneaux de kholles' : "
                f"'{attendu}' attendu, '{headers[i - 1]}' trouvé."
            )

    semaines_excel = []
    for col in range(5, ws.max_column + 1):
        valeur = ws.cell(1, col).value
        match = re.fullmatch(r"\s*Semaine\s+(\d+)\s*", str(valeur))
        if not match:
            raise ValueError(
                f"En-tête de semaine invalide dans 'Créneaux de kholles' : "
                f"'{valeur}'."
            )
        semaines_excel.append(int(match.group(1)))

    if not semaines_excel:
        raise ValueError("Aucune semaine trouvée dans 'Créneaux de kholles'.")

    if semaines_excel != list(range(1, len(semaines_excel) + 1)):
        raise ValueError(
            "Les colonnes de semaines de 'Créneaux de kholles' doivent être "
            "Semaine 1, Semaine 2, ..., sans trou."
        )

    NOMBRE_SEMAINES = len(semaines_excel)

    creneaux = []
    for ligne in range(2, ws.max_row + 1):
        matiere = ws.cell(ligne, 1).value
        colleur = ws.cell(ligne, 2).value
        jour = ws.cell(ligne, 3).value
        heure = ws.cell(ligne, 4).value

        # Ignore une ligne entièrement vide.
        if all(
            ws.cell(ligne, col).value in (None, "")
            for col in range(1, ws.max_column + 1)
        ):
            continue

        valeurs_manquantes = []
        for nom, valeur in [
            ("Matière", matiere),
            ("Colleur", colleur),
            ("Jour", jour),
            ("Heure", heure),
        ]:
            if valeur is None or str(valeur).strip() == "":
                valeurs_manquantes.append(nom)

        if valeurs_manquantes:
            raise ValueError(
                f"Ligne {ligne} de 'Créneaux de kholles' : "
                f"champ(s) manquant(s) : {', '.join(valeurs_manquantes)}."
            )

        matiere = str(matiere).strip()
        colleur = str(colleur).strip()
        jour = str(jour).strip()
        heure = normaliser_heure(heure)

        semaines_disponibles = []
        for offset, semaine in enumerate(semaines_excel):
            valeur = ws.cell(ligne, 5 + offset).value
            if valeur is None or str(valeur).strip() == "":
                semaines_disponibles.append(semaine)

        if not semaines_disponibles:
            raise ValueError(
                f"Ligne {ligne} : le créneau '{matiere} / {colleur} / "
                f"{jour} {heure}' n'est disponible aucune semaine."
            )

        creneaux.append(
            creer_creneau(
                matiere=matiere,
                jour=jour,
                heure=heure,
                colleur=colleur,
                semaines_disponibles=semaines_disponibles,
            )
        )

    CRENEAUX = creneaux

    # --------------------------------------------------------
    # Feuille 2 : alternance des matières
    # --------------------------------------------------------
    ws_alt = wb["Alternance des matières"]

    if ws_alt.max_column < 2:
        raise ValueError(
            "La feuille 'Alternance des matières' doit contenir "
            "au moins Groupe + une semaine-type."
        )

    if str(ws_alt.cell(1, 1).value).strip().lower() != "groupe":
        raise ValueError(
            "La première colonne de 'Alternance des matières' doit être 'Groupe'."
        )

    types_excel = []
    for col in range(2, ws_alt.max_column + 1):
        attendu = f"Semaine {col - 1}"
        valeur = ws_alt.cell(1, col).value
        if str(valeur).strip().lower() != attendu.lower():
            raise ValueError(
                f"Colonne {col} de 'Alternance des matières' : "
                f"'{attendu}' attendu, '{valeur}' trouvé."
            )
        types_excel.append(col - 1)

    cycle_alternance = len(types_excel)
    alternance = {}
    for ligne in range(2, ws_alt.max_row + 1):
        groupe_valeur = ws_alt.cell(ligne, 1).value

        if groupe_valeur is None or str(groupe_valeur).strip() == "":
            continue

        try:
            groupe = int(groupe_valeur)
        except (TypeError, ValueError) as exc:
            raise ValueError(
                f"Ligne {ligne} de 'Alternance des matières' : "
                f"groupe invalide '{groupe_valeur}'."
            ) from exc

        types = []
        for col in range(2, ws_alt.max_column + 1):
            valeur = ws_alt.cell(ligne, col).value
            if valeur is None or str(valeur).strip() == "":
                raise ValueError(
                    f"Groupe {groupe}, semaine-type {col - 1} : alternance vide."
                )

            texte = str(valeur).strip()
            morceaux = [x.strip() for x in texte.split("+")]

            if len(morceaux) != 2 or not morceaux[0] or not morceaux[1]:
                raise ValueError(
                    f"Groupe {groupe}, semaine-type {col - 1} : "
                    f"format attendu 'Matière 1 + Matière 2', trouvé '{texte}'."
                )

            types.append(morceaux)

        if groupe in alternance:
            raise ValueError(f"Groupe {groupe} apparaît plusieurs fois.")

        alternance[groupe] = types

    if not alternance:
        raise ValueError("Aucun groupe trouvé dans 'Alternance des matières'.")

    GROUPES = sorted(alternance)
    ALTERNANCE = alternance
    CYCLE_ALTERNANCE = cycle_alternance

    # --------------------------------------------------------
    # Feuille 3 : contraintes horaires par groupe
    # --------------------------------------------------------
    CONTRAINTES_HORAIRES.clear()
    if "Contraintes horaires" in wb.sheetnames:
        ws_contraintes = wb["Contraintes horaires"]

        if ws_contraintes.max_column < 4:
            raise ValueError(
                "La feuille 'Contraintes horaires' doit contenir les colonnes "
                "'Groupe', 'Jour', 'Indisponible à partir de' et 'Jusqu’à'."
            )

        entetes = [
            str(ws_contraintes.cell(1, col).value).strip().lower()
            if ws_contraintes.cell(1, col).value is not None else ""
            for col in range(1, 5)
        ]
        if entetes[0] != "groupe" or entetes[1] != "jour"                 or entetes[2] != "indisponible à partir de"                 or entetes[3] not in {"jusqu’à", "jusqu'à"}:
            raise ValueError(
                "La feuille 'Contraintes horaires' doit commencer par : "
                "Groupe | Jour | Indisponible à partir de | Jusqu’à"
            )

        for ligne in range(2, ws_contraintes.max_row + 1):
            valeurs = [
                ws_contraintes.cell(ligne, col).value
                for col in range(1, 5)
            ]
            if all(v is None or str(v).strip() == "" for v in valeurs):
                continue

            groupe_valeur, jour_valeur, debut_valeur, fin_valeur = valeurs

            try:
                groupe = int(groupe_valeur)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"Ligne {ligne} de 'Contraintes horaires' : "
                    f"groupe invalide '{groupe_valeur}'."
                ) from exc

            if groupe not in GROUPES:
                raise ValueError(
                    f"Ligne {ligne} de 'Contraintes horaires' : "
                    f"le groupe {groupe} n'existe pas dans "
                    "'Alternance des matières'."
                )

            jour = str(jour_valeur).strip() if jour_valeur is not None else ""
            if jour not in JOURS_ORDRE:
                raise ValueError(
                    f"Ligne {ligne} de 'Contraintes horaires' : "
                    f"jour invalide '{jour}'."
                )

            debut = heure_contrainte_en_minutes(debut_valeur, 0)
            fin = heure_contrainte_en_minutes(fin_valeur, 24 * 60 - 1)

            if debut >= fin:
                raise ValueError(
                    f"Ligne {ligne} de 'Contraintes horaires' : "
                    "la plage horaire doit avoir un début inférieur à la fin."
                )

            CONTRAINTES_HORAIRES.setdefault(groupe, []).append(
                (jour, debut, fin)
            )

    # Matières importées automatiquement depuis l’alternance.
    MATIERES.clear()
    for groupe in GROUPES:
        for type_matieres in ALTERNANCE[groupe]:
            for matiere in type_matieres:
                if matiere not in MATIERES:
                    MATIERES.append(matiere)
    MATIERE_RANG.clear()
    MATIERE_RANG.update({matiere: rang for rang, matiere in enumerate(MATIERES)})


# ============================================================
# VALIDATION DE LA CONFIGURATION
# ============================================================

def matieres_demandees(groupe: int, semaine: int) -> List[str]:
    type_semaine = (semaine - 1) % CYCLE_ALTERNANCE
    return ALTERNANCE[groupe][type_semaine]


def valider_configuration() -> None:
    erreurs = []

    if not GROUPES:
        erreurs.append("Aucun groupe trouvé dans la feuille 'Alternance des matières'.")

    if NOMBRE_SEMAINES <= 0:
        erreurs.append("Aucune semaine trouvée dans la feuille 'Créneaux de kholles'.")

    for groupe in GROUPES:
        if groupe not in ALTERNANCE:
            erreurs.append(f"Groupe {groupe}: alternance absente.")
            continue

        if len(ALTERNANCE[groupe]) != CYCLE_ALTERNANCE:
            erreurs.append(
                f"Groupe {groupe}: l'alternance doit contenir exactement {CYCLE_ALTERNANCE} semaine(s)-type(s)."
            )
            continue

        for type_semaine, matieres in enumerate(ALTERNANCE[groupe], start=1):
            if len(matieres) != 2:
                erreurs.append(
                    f"Groupe {groupe}, type {type_semaine}: "
                    "il faut exactement 2 matières."
                )
            elif matieres[0] == matieres[1]:
                erreurs.append(
                    f"Groupe {groupe}, type {type_semaine}: "
                    "les 2 matières doivent être distinctes."
                )

            for matiere in matieres:
                if matiere not in MATIERES:
                    erreurs.append(
                        f"Groupe {groupe}, type {type_semaine}: "
                        f"matière invalide '{matiere}'."
                    )

    matieres_creneaux = {c.matiere for c in CRENEAUX}
    matieres_alternance = set(MATIERES)
    if matieres_creneaux != matieres_alternance:
        manquantes = sorted(
            matieres_alternance - matieres_creneaux,
            key=lambda m: MATIERE_RANG[m],
        )
        superflues = sorted(matieres_creneaux - matieres_alternance)
        if manquantes:
            erreurs.append(
                "Matière(s) de l'alternance absente(s) de 'Créneaux de kholles' : "
                + ", ".join(manquantes)
            )
        if superflues:
            erreurs.append(
                "Matière(s) présente(s) dans 'Créneaux de kholles' mais absente(s) de "
                "'Alternance des matières' : " + ", ".join(superflues)
            )

    for i, creneau in enumerate(CRENEAUX):
        if not creneau.semaines_disponibles:
            erreurs.append(f"Créneau {i}: aucune semaine disponible.")

        for semaine in creneau.semaines_disponibles:
            if semaine < 1 or semaine > NOMBRE_SEMAINES:
                erreurs.append(
                    f"Créneau {i}: semaine invalide {semaine}."
                )

    if erreurs:
        raise ValueError(
            "Configuration invalide :\n- " + "\n- ".join(erreurs)
        )


# ============================================================
# CONTRAINTES DE TEMPS
# ============================================================

def intervalles_se_recouvrent(a: Creneau, b: Creneau) -> bool:
    """Contrainte DURE : les deux colles se chevauchent réellement."""
    if a.jour != b.jour:
        return False

    debut_a = a.minutes
    fin_a = a.minutes + DUREE_COLLE_MINUTES
    debut_b = b.minutes
    fin_b = b.minutes + DUREE_COLLE_MINUTES

    return max(debut_a, debut_b) < min(fin_a, fin_b)


def battement_insuffisant(a: Creneau, b: Creneau) -> bool:
    """Préférence SOUPLE : moins de 30 min entre deux colles."""
    if a.jour != b.jour:
        return False

    if a.minutes <= b.minutes:
        battement = b.minutes - (a.minutes + DUREE_COLLE_MINUTES)
    else:
        battement = a.minutes - (b.minutes + DUREE_COLLE_MINUTES)

    return 0 <= battement < BATTEMENT_SOUHAITE_MINUTES


# ============================================================
# GENERATION
# ============================================================

def generer_planning():
    valider_configuration()

    model = cp_model.CpModel()

    # x[groupe, semaine, créneau] = 1 si le groupe a cette khôlle.
    x = {}

    for groupe in GROUPES:
        for semaine in range(1, NOMBRE_SEMAINES + 1):
            matieres = set(matieres_demandees(groupe, semaine))

            for idx, creneau in enumerate(CRENEAUX):
                if semaine not in creneau.semaines_disponibles:
                    continue
                if creneau.matiere not in matieres:
                    continue
                if creneau_interdit_pour_groupe(groupe, creneau):
                    continue

                x[(groupe, semaine, idx)] = model.NewBoolVar(
                    f"x_g{groupe}_s{semaine}_c{idx}"
                )

    # --------------------------------------------------------
    # Chaque groupe doit avoir exactement une khôlle dans
    # chacun de ses 2 créneaux de matière.
    # --------------------------------------------------------

    for groupe in GROUPES:
        for semaine in range(1, NOMBRE_SEMAINES + 1):
            for matiere in matieres_demandees(groupe, semaine):
                variables = [
                    var
                    for (g, s, idx), var in x.items()
                    if g == groupe
                    and s == semaine
                    and CRENEAUX[idx].matiere == matiere
                ]

                if not variables:
                    raise RuntimeError(
                        f"Aucun créneau disponible pour {matiere}, "
                        f"groupe {groupe}, semaine {semaine}."
                    )

                model.Add(sum(variables) == 1)

    # --------------------------------------------------------
    # Un même créneau exact ne peut accueillir qu'un groupe.
    # --------------------------------------------------------

    for semaine in range(1, NOMBRE_SEMAINES + 1):
        for idx in range(len(CRENEAUX)):
            variables = [
                var
                for (g, s, i), var in x.items()
                if s == semaine and i == idx
            ]
            if variables:
                model.Add(sum(variables) <= 1)

    # --------------------------------------------------------
    # Pas de chevauchement / enchaînement direct pour un groupe.
    # --------------------------------------------------------

    for groupe in GROUPES:
        for semaine in range(1, NOMBRE_SEMAINES + 1):
            indices = [
                idx
                for (g, s, idx) in x
                if g == groupe and s == semaine
            ]

            for pos_a in range(len(indices)):
                for pos_b in range(pos_a + 1, len(indices)):
                    idx_a = indices[pos_a]
                    idx_b = indices[pos_b]

                    if intervalles_se_recouvrent(
                        CRENEAUX[idx_a], CRENEAUX[idx_b]
                    ):
                        model.Add(
                            x[(groupe, semaine, idx_a)]
                            + x[(groupe, semaine, idx_b)]
                            <= 1
                        )

    # --------------------------------------------------------
    # Maximum 2 khôlles par jour et par groupe.
    # --------------------------------------------------------

    for groupe in GROUPES:
        for semaine in range(1, NOMBRE_SEMAINES + 1):
            for jour in JOURS_ORDRE:
                variables = [
                    var
                    for (g, s, idx), var in x.items()
                    if g == groupe
                    and s == semaine
                    and CRENEAUX[idx].jour == jour
                ]

                if variables:
                    model.Add(sum(variables) <= MAX_COLLES_PAR_JOUR)

    # --------------------------------------------------------
    # OBJECTIFS SOUPLES
    # --------------------------------------------------------
    #
    # Pour chaque groupe + matière, on cherche à :
    #
    # 1. répartir les colleurs proportionnellement au nombre
    #    de créneaux dont ils disposent ;
    # 2. éviter les répétitions immédiates d'un même colleur ;
    # 3. éviter les répétitions rapprochées ;
    # 4. faire également tourner les créneaux ;
    #
    # --------------------------------------------------------

    couts = []

    # ---------- Préférence : deux khôlles le même jour ----------
    for groupe in GROUPES:
        for semaine in range(1, NOMBRE_SEMAINES + 1):
            for jour in JOURS_ORDRE:
                variables = [
                    var
                    for (g, s, idx), var in x.items()
                    if g == groupe
                    and s == semaine
                    and CRENEAUX[idx].jour == jour
                ]

                if variables:
                    y = model.NewBoolVar(
                        f"deux_meme_jour_g{groupe}_s{semaine}_{jour}"
                    )
                    model.Add(sum(variables) <= 1 + y)
                    couts.append(POIDS["deux_colles_meme_jour"] * y)

    # ---------- Équité : répartition des doubles journées ----------
    #
    # On compte, pour chaque groupe, le nombre de semaines où ses
    # deux colles ont lieu le même jour.
    #
    # Puis on pénalise les écarts absolus entre groupes.
    #
    # Exemple :
    #   [2, 3, 3, 4, 4, ...] sera préféré à
    #   [0, 1, 2, 8, 8, ...]
    #
    # Cette préférence porte sur l'ensemble des semaines configurées :
    # elle ne cherche donc pas à imposer le même nombre chaque semaine.
    nb_doubles_jour = {}

    for groupe in GROUPES:
        doubles = []

        for semaine in range(1, NOMBRE_SEMAINES + 1):
            doubles_semaine = []

            for jour in JOURS_ORDRE:
                variables = [
                    var
                    for (g, s, idx), var in x.items()
                    if g == groupe
                    and s == semaine
                    and CRENEAUX[idx].jour == jour
                ]

                if variables:
                    # Comme le modèle impose exactement 2 colles/semaine
                    # et maximum 2/jour, cette variable vaut 1 exactement
                    # lorsqu'il y a 2 colles ce jour-là.
                    y = model.NewBoolVar(
                        f"double_equite_g{groupe}_s{semaine}_{jour}"
                    )
                    model.Add(sum(variables) <= 1 + y)
                    model.Add(sum(variables) >= 2 * y)
                    doubles_semaine.append(y)

            # Une seule journée peut contenir les deux colles du groupe,
            # donc la somme des indicateurs vaut 0 ou 1.
            if doubles_semaine:
                double_semaine = model.NewBoolVar(
                    f"double_equite_semaine_g{groupe}_s{semaine}"
                )
                model.Add(double_semaine == sum(doubles_semaine))
            else:
                double_semaine = model.NewConstant(0)

            doubles.append(double_semaine)

        total = model.NewIntVar(
            0,
            NOMBRE_SEMAINES,
            f"nb_doubles_jour_g{groupe}"
        )
        model.Add(total == sum(doubles))
        nb_doubles_jour[groupe] = total

    # Écart absolu entre chaque paire de groupes.
    # C'est ce qui empêche un petit nombre de groupes de concentrer
    # toutes les doubles journées.
    for pos_a, groupe_a in enumerate(GROUPES):
        for groupe_b in GROUPES[pos_a + 1:]:
            ecart = model.NewIntVar(
                0,
                NOMBRE_SEMAINES,
                f"ecart_doubles_g{groupe_a}_g{groupe_b}"
            )
            model.AddAbsEquality(
                ecart,
                nb_doubles_jour[groupe_a] - nb_doubles_jour[groupe_b]
            )
            couts.append(
                POIDS["equilibre_deux_colles_meme_jour"] * ecart
            )

    # ---------- Équité renforcée : écart maximum-minimum ----------
    #
    # Le critère précédent compare chaque paire de groupes. On ajoute
    # ici un critère encore plus direct : minimiser l'écart entre le
    # groupe qui a le PLUS de journées à 2 colles et celui qui en a
    # le MOINS.
    #
    # Ainsi, une répartition du type :
    #     0, 0, 0, 0, 0, 7
    # est fortement défavorisée par rapport à :
    #     1, 1, 1, 2, 1, 1
    #
    # Il s'agit toujours d'une préférence SOUPLE : on ne rend pas
    # impossible une solution qui aurait un léger déséquilibre si
    # celui-ci permet de satisfaire des contraintes/préférences plus
    # importantes.
    minimum_doubles = model.NewIntVar(
        0,
        NOMBRE_SEMAINES,
        "minimum_doubles_jour"
    )
    maximum_doubles = model.NewIntVar(
        0,
        NOMBRE_SEMAINES,
        "maximum_doubles_jour"
    )

    model.AddMinEquality(
        minimum_doubles,
        [nb_doubles_jour[groupe] for groupe in GROUPES]
    )
    model.AddMaxEquality(
        maximum_doubles,
        [nb_doubles_jour[groupe] for groupe in GROUPES]
    )

    ecart_max_min = model.NewIntVar(
        0,
        NOMBRE_SEMAINES,
        "ecart_max_min_doubles_jour"
    )
    model.Add(
        ecart_max_min == maximum_doubles - minimum_doubles
    )
    couts.append(
        POIDS["ecart_max_min_deux_colles_meme_jour"] * ecart_max_min
    )

    # ---------- Préférence : éviter les battements courts ----------
    #
    # Le chevauchement est une contrainte DURE.
    # Ici, on pénalise seulement un battement de 0 à 29 minutes.
    #
    for groupe in GROUPES:
        for semaine in range(1, NOMBRE_SEMAINES + 1):
            indices = [
                idx
                for (g, s, idx) in x
                if g == groupe and s == semaine
            ]

            for pos_a in range(len(indices)):
                for pos_b in range(pos_a + 1, len(indices)):
                    idx_a = indices[pos_a]
                    idx_b = indices[pos_b]

                    if battement_insuffisant(
                        CRENEAUX[idx_a], CRENEAUX[idx_b]
                    ):
                        paire = model.NewBoolVar(
                            f"enchainement_colles_g{groupe}_s{semaine}_c{idx_a}_c{idx_b}"
                        )
                        var_a = x[(groupe, semaine, idx_a)]
                        var_b = x[(groupe, semaine, idx_b)]

                        model.Add(paire <= var_a)
                        model.Add(paire <= var_b)
                        model.Add(paire >= var_a + var_b - 1)

                        couts.append(POIDS["enchainement_colles"] * paire)

    # ---------- Roulement par groupe + matière ----------
    #
    # On travaille sur les semaines où le groupe a cette matière.
    # Les créneaux réellement disponibles servent à calculer la
    # fréquence naturelle de chaque colleur.
    #

    for groupe in GROUPES:
        for matiere in MATIERES:

            semaines_matiere = [
                semaine
                for semaine in range(1, NOMBRE_SEMAINES + 1)
                if matiere in matieres_demandees(groupe, semaine)
            ]

            if not semaines_matiere:
                continue

            # Créneaux de cette matière réellement utilisables au
            # moins une fois pendant l'année.
            creneaux_matiere = [
                idx for idx, c in enumerate(CRENEAUX)
                if c.matiere == matiere
                and any(
                    semaine in c.semaines_disponibles
                    for semaine in semaines_matiere
                )
            ]

            if not creneaux_matiere:
                continue

            colleurs = sorted(
                {CRENEAUX[idx].colleur for idx in creneaux_matiere},
                key=lambda p: p.lower(),
            )

            # ----------------------------------------------------
            # Priorité très forte : voir chaque colleur
            # ----------------------------------------------------
            #
            # Si plusieurs colleurs sont disponibles pour une matière,
            # on pénalise très fortement le fait qu'un groupe n'en voie
            # jamais un.
            #
            # C'est une préférence SOUPLE : elle n'est jamais imposée
            # comme contrainte dure. Si les autres contraintes rendent
            # la diversité impossible, le solveur peut s'en écarter.
            #
            # "variables_prof" contient toutes les affectations possibles
            # de ce groupe avec ce colleur pour cette matière.
            # ----------------------------------------------------

            for prof in colleurs:
                variables_prof = [
                    var
                    for (g, s, idx), var in x.items()
                    if g == groupe
                    and s in semaines_matiere
                    and idx in creneaux_matiere
                    and CRENEAUX[idx].colleur == prof
                ]

                if not variables_prof:
                    continue

                vu_prof = model.NewBoolVar(
                    f"vu_prof_g{groupe}_{matiere}_{len(couts)}"
                )

                # vu_prof = 1 dès qu'au moins une des affectations
                # correspondantes est choisie.
                model.AddMaxEquality(vu_prof, variables_prof)

                couts.append(
                    POIDS["colleur_jamais_vu"] * (1 - vu_prof)
                )

            # ----------------------------------------------------
            # Equilibrage pondéré des colleurs
            # ----------------------------------------------------
            #
            # OBJECTIF SOUPLE :
            # on ne force jamais une répartition donnée.
            #
            # Pour un total T de khôlles et des capacités c_p,
            # la cible théorique du colleur p est :
            #
            #        T * c_p / somme(c_p)
            #
            # Cette valeur peut être fractionnaire. On pénalise donc
            # uniquement l'écart à cette cible, sans imposer de
            # contrainte dure de répartition.
            #
            # L'utilisation de deux variables d'écart (au-dessus et
            # au-dessous) rend l'objectif totalement souple.
            # ----------------------------------------------------

            total_affectations = len(semaines_matiere)

            capacites_prof = {
                prof: sum(
                    1
                    for idx in creneaux_matiere
                    if CRENEAUX[idx].colleur == prof
                )
                for prof in colleurs
            }
            total_capacite_prof = sum(capacites_prof.values())

            for prof in colleurs:
                variables_prof = [
                    var
                    for (g, s, idx), var in x.items()
                    if g == groupe
                    and s in semaines_matiere
                    and idx in creneaux_matiere
                    and CRENEAUX[idx].colleur == prof
                ]

                if not variables_prof:
                    continue

                compte_prof = model.NewIntVar(
                    0,
                    total_affectations,
                    f"compte_prof_g{groupe}_{matiere}_{len(couts)}",
                )
                model.Add(compte_prof == sum(variables_prof))

                # On compare T * compte_prof avec la cible entière
                # T * T * capacite_prof / total_capacite_prof.
                #
                # La multiplication par total_capacite_prof évite
                # toute division dans CP-SAT.
                cible_numerateur = (
                    total_affectations * capacites_prof[prof]
                )

                ecart_prof = model.NewIntVar(
                    0,
                    total_affectations * total_capacite_prof,
                    f"ecart_prof_g{groupe}_{matiere}_{prof}_{len(couts)}",
                )

                expression = (
                    total_capacite_prof * compte_prof
                    - cible_numerateur
                )
                model.AddAbsEquality(ecart_prof, expression)

                couts.append(
                    POIDS["desequilibre_colleur"] * ecart_prof
                )

            # ----------------------------------------------------
            # Répétitions immédiates d'un même colleur
            # ----------------------------------------------------
            #
            # On regarde les occurrences consécutives de la matière.
            #
            for pos in range(len(semaines_matiere) - 1):
                s1 = semaines_matiere[pos]
                s2 = semaines_matiere[pos + 1]

                for prof in colleurs:
                    v1 = [
                        var
                        for (g, s, idx), var in x.items()
                        if g == groupe
                        and s == s1
                        and idx in creneaux_matiere
                        and CRENEAUX[idx].colleur == prof
                    ]
                    v2 = [
                        var
                        for (g, s, idx), var in x.items()
                        if g == groupe
                        and s == s2
                        and idx in creneaux_matiere
                        and CRENEAUX[idx].colleur == prof
                    ]

                    if v1 and v2:
                        # Chaque liste vaut 0 ou 1, car une seule
                        # khôlle de cette matière est choisie.
                        repeat = model.NewBoolVar(
                            f"repeat_prof_g{groupe}_{matiere}_{s1}_{s2}_{len(couts)}"
                        )
                        model.Add(repeat <= sum(v1))
                        model.Add(repeat <= sum(v2))
                        model.Add(repeat >= sum(v1) + sum(v2) - 1)
                        couts.append(
                            POIDS["repetition_colleur_consecutif"]
                            * repeat
                        )

            # ----------------------------------------------------
            # Répétitions rapprochées
            # ----------------------------------------------------
            #
            # Pour chaque fenêtre de 3 occurrences consécutives,
            # on pénalise le fait de revoir le même colleur à
            # moins de deux occurrences d'intervalle.
            #
            # Cela pousse vers A-B-C plutôt que A-B-A lorsque
            # plusieurs colleurs sont disponibles.
            #
            for pos in range(len(semaines_matiere) - 2):
                s1 = semaines_matiere[pos]
                s3 = semaines_matiere[pos + 2]

                for prof in colleurs:
                    v1 = [
                        var
                        for (g, s, idx), var in x.items()
                        if g == groupe
                        and s == s1
                        and idx in creneaux_matiere
                        and CRENEAUX[idx].colleur == prof
                    ]
                    v3 = [
                        var
                        for (g, s, idx), var in x.items()
                        if g == groupe
                        and s == s3
                        and idx in creneaux_matiere
                        and CRENEAUX[idx].colleur == prof
                    ]

                    if v1 and v3:
                        repeat = model.NewBoolVar(
                            f"repeat_near_prof_g{groupe}_{matiere}_{s1}_{s3}_{len(couts)}"
                        )
                        model.Add(repeat <= sum(v1))
                        model.Add(repeat <= sum(v3))
                        model.Add(repeat >= sum(v1) + sum(v3) - 1)
                        couts.append(
                            POIDS["repetition_colleur_proche"]
                            * repeat
                        )

            # ----------------------------------------------------
            # Roulement des créneaux
            # ----------------------------------------------------
            #
            # Préférence secondaire : répartir les affectations entre
            # les créneaux disponibles, en tenant compte de leur
            # disponibilité réelle sur les semaines concernées.
            # ----------------------------------------------------

            capacites_creneau = {
                idx: sum(
                    1
                    for s in semaines_matiere
                    if s in CRENEAUX[idx].semaines_disponibles
                )
                for idx in creneaux_matiere
            }

            capacite_totale_creneaux = sum(capacites_creneau.values())

            for idx in creneaux_matiere:
                variables_creneau = [
                    var
                    for (g, s, i), var in x.items()
                    if g == groupe
                    and s in semaines_matiere
                    and i == idx
                ]

                if not variables_creneau:
                    continue

                capacite_creneau = capacites_creneau[idx]
                if capacite_creneau == 0:
                    continue

                compte = model.NewIntVar(
                    0,
                    total_affectations,
                    f"compte_creneau_g{groupe}_{matiere}_{idx}",
                )
                model.Add(compte == sum(variables_creneau))

                ecart = model.NewIntVar(
                    0,
                    total_affectations * capacite_totale_creneaux,
                    f"ecart_creneau_g{groupe}_{matiere}_{idx}",
                )

                expression = (
                    capacite_totale_creneaux * compte
                    - capacite_creneau * total_affectations
                )
                model.AddAbsEquality(ecart, expression)

                couts.append(
                    POIDS["desequilibre_creneau"] * ecart
                )

            # Répétition immédiate du même créneau.
            for pos in range(len(semaines_matiere) - 1):
                s1 = semaines_matiere[pos]
                s2 = semaines_matiere[pos + 1]

                for idx in creneaux_matiere:
                    v1 = x.get((groupe, s1, idx))
                    v2 = x.get((groupe, s2, idx))

                    if v1 is not None and v2 is not None:
                        repeat = model.NewBoolVar(
                            f"repeat_creneau_g{groupe}_{matiere}_{idx}_{s1}_{s2}"
                        )
                        model.Add(repeat <= v1)
                        model.Add(repeat <= v2)
                        model.Add(repeat >= v1 + v2 - 1)

                        couts.append(
                            POIDS["repetition_creneau_consecutif"]
                            * repeat
                        )

    model.Minimize(sum(couts))

    # --------------------------------------------------------
    # Diagnostic de faisabilité élémentaire
    # --------------------------------------------------------
    for groupe in GROUPES:
        for semaine in range(1, NOMBRE_SEMAINES + 1):
            for matiere in matieres_demandees(groupe, semaine):
                disponibles = [
                    idx
                    for idx, c in enumerate(CRENEAUX)
                    if c.matiere == matiere
                    and semaine in c.semaines_disponibles
                ]
                if not disponibles:
                    raise RuntimeError(
                        f"INFEASIBLE : aucun créneau {matiere} disponible "
                        f"pour le groupe {groupe}, semaine {semaine}."
                    )

    # --------------------------------------------------------
    # Solveur
    # --------------------------------------------------------

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = TEMPS_MAX_SOLVEUR
    solver.parameters.random_seed = SEED_SOLVEUR
    solver.parameters.num_search_workers = 8

    statut = solver.Solve(model)

    if statut not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        raise RuntimeError(
            "Le solveur n'a pas trouvé de planning valide. "
            f"Statut : {solver.StatusName(statut)}"
        )

    planning = []

    for groupe in GROUPES:
        for semaine in range(1, NOMBRE_SEMAINES + 1):
            for idx, creneau in enumerate(CRENEAUX):
                var = x.get((groupe, semaine, idx))
                if var is not None and solver.Value(var):
                    planning.append(
                        {
                            "groupe": groupe,
                            "semaine": semaine,
                            "matiere": creneau.matiere,
                            "colleur": creneau.colleur,
                            "jour": creneau.jour,
                            "heure": creneau.heure,
                            "minutes": creneau.minutes,
                            "creneau_index": idx,
                        }
                    )

    return planning


# ============================================================
# VALIDATION DU PLANNING PRODUIT
# ============================================================

def valider_planning(planning: List[dict]) -> None:
    erreurs = []

    # Chaque groupe/semaine : exactement 2 khôlles et les 2
    # matières prévues.
    for groupe in GROUPES:
        for semaine in range(1, NOMBRE_SEMAINES + 1):
            lignes = [
                x for x in planning
                if x["groupe"] == groupe and x["semaine"] == semaine
            ]

            matieres = sorted(
                [x["matiere"] for x in lignes],
                key=lambda m: MATIERE_RANG[m]
            )
            attendues = sorted(
                matieres_demandees(groupe, semaine),
                key=lambda m: MATIERE_RANG[m]
            )

            if len(lignes) != 2:
                erreurs.append(
                    f"Groupe {groupe}, semaine {semaine}: "
                    f"{len(lignes)} khôlles au lieu de 2."
                )

            if matieres != attendues:
                erreurs.append(
                    f"Groupe {groupe}, semaine {semaine}: "
                    f"matières {matieres}, attendues {attendues}."
                )

            # Pas de conflit temporel pour le groupe.
            for i in range(len(lignes)):
                for j in range(i + 1, len(lignes)):
                    a = planning_ligne_vers_creneau(lignes[i])
                    b = planning_ligne_vers_creneau(lignes[j])

                    if intervalles_se_recouvrent(a, b):
                        erreurs.append(
                            f"Groupe {groupe}, semaine {semaine}: "
                            f"conflit entre {a.jour} {a.heure} et "
                            f"{b.jour} {b.heure}."
                        )

    # Un créneau exact ne peut être utilisé par plusieurs groupes.
    vus = {}
    for ligne in planning:
        cle = (
            ligne["semaine"],
            ligne["creneau_index"],
        )
        if cle in vus:
            erreurs.append(
                f"Semaine {ligne['semaine']}: le créneau "
                f"{ligne['creneau_index']} est utilisé par plusieurs groupes "
                f"({vus[cle]} et {ligne['groupe']})."
            )
        else:
            vus[cle] = ligne["groupe"]

    if erreurs:
        raise RuntimeError(
            "Le planning généré échoue la validation :\n- "
            + "\n- ".join(erreurs)
        )


def planning_ligne_vers_creneau(ligne: dict) -> Creneau:
    return Creneau(
        matiere=ligne["matiere"],
        jour=ligne["jour"],
        heure=ligne["heure"],
        minutes=ligne["minutes"],
        colleur=ligne["colleur"],
        semaines_disponibles=(ligne["semaine"],),
    )


# ============================================================
# EXPORT EXCEL
# ============================================================

def exporter_excel(planning: List[dict], fichier: str = FICHIER_SORTIE) -> Path:
    chemin = Path(fichier)

    wb = Workbook()
    ws = wb.active
    ws.title = "Planning"

    # --------------------------------------------------------
    # Feuille principale : une ligne = un créneau
    # --------------------------------------------------------

    lignes = []

    cles = sorted(
        {
            (
                x["matiere"],
                x["colleur"],
                x["jour"],
                x["heure"],
                x["creneau_index"],
            )
            for x in planning
        },
        key=lambda k: (
            MATIERE_RANG[k[0]],
            k[1].lower(),
            JOURS_ORDRE.get(k[2], 99),
            heure_en_minutes(k[3]),
            k[4],
        ),
    )

    for matiere, colleur, jour, heure, creneau_index in cles:
        ligne = [matiere, colleur, jour, heure]

        for semaine in range(1, NOMBRE_SEMAINES + 1):
            groupes = [
                x["groupe"]
                for x in planning
                if x["semaine"] == semaine
                and x["creneau_index"] == creneau_index
            ]
            ligne.append(groupes[0] if groupes else "")

        lignes.append(ligne)

    entetes = (
        ["Matière", "Colleur", "Jour", "Heure"]
        + [f"Semaine {s}" for s in range(1, NOMBRE_SEMAINES + 1)]
    )

    ws.append(entetes)

    for ligne in lignes:
        ws.append(ligne)

    styliser_feuille_planning(ws, len(lignes) + 1, len(entetes))

    # --------------------------------------------------------
    # Mise en page générale
    # --------------------------------------------------------

    for feuille in wb.worksheets:
        feuille.sheet_view.showGridLines = False
        feuille.freeze_panes = "A2"

    ws.auto_filter.ref = ws.dimensions

    wb.save(chemin)

    return chemin


def styliser_feuille_planning(ws, nb_lignes: int, nb_colonnes: int) -> None:
    # En-tête
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E78")
        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
            wrap_text=True,
        )

    ws.row_dimensions[1].height = 30

    # Corps
    for row in ws.iter_rows(min_row=2, max_row=nb_lignes):
        for cell in row:
            cell.alignment = Alignment(
                horizontal="center",
                vertical="center",
            )

    # Matière en gras et lignes regroupées visuellement.
    ancienne_matiere = None
    for row in range(2, nb_lignes + 1):
        matiere = ws.cell(row=row, column=1).value

        if matiere != ancienne_matiere:
            for col in range(1, nb_colonnes + 1):
                ws.cell(row=row, column=col).border = Border(
                    top=Side(style="medium")
                )
            ancienne_matiere = matiere

        ws.cell(row=row, column=1).font = Font(bold=True)

    # Largeurs
    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 20
    ws.column_dimensions["C"].width = 12
    ws.column_dimensions["D"].width = 10

    for col in range(5, nb_colonnes + 1):
        ws.column_dimensions[get_column_letter(col)].width = 11

    # Ligne vide visuelle non nécessaire : le tableau Excel assure les filtres.
    ref = f"A1:{get_column_letter(nb_colonnes)}{nb_lignes}"
    table = Table(displayName="TablePlanning", ref=ref)
    style = TableStyleInfo(
        name="TableStyleMedium2",
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False,
    )
    table.tableStyleInfo = style
    ws.add_table(table)



# ============================================================
# MAIN
# ============================================================

def main() -> None:
    print(f"Chargement de la configuration depuis '{FICHIER_CONFIGURATION}'...")
    charger_configuration_excel()

    print("\nConfiguration détectée dans input.xlsx :")
    print("- Matières : " + ", ".join(MATIERES))
    print(f"- Longueur du cycle d'alternance : {CYCLE_ALTERNANCE} semaine(s)")
    print(f"- Nombre total de groupes : {len(GROUPES)}")
    print(f"- Nombre total de semaines : {NOMBRE_SEMAINES}")
    print(f"- Contraintes horaires spécifiques : {sum(len(v) for v in CONTRAINTES_HORAIRES.values())}")

    print("\nValidation de la configuration...")
    valider_configuration()

    input("\nAppuyez sur Entrée pour lancer la conception du planning...")

    print("\nGénération du planning...")
    planning = generer_planning()

    print("Validation du planning généré...")
    valider_planning(planning)

    print("Export Excel...")
    fichier = exporter_excel(planning)

    print()
    print("Planning généré avec succès.")
    print(f"Fichier : {fichier.resolve()}")


if __name__ == "__main__":
    main()
