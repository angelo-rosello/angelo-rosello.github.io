﻿
# -*- coding: utf-8 -*-
"""
ANALYSEUR DE PLANNING DE KHOLLES 

Entrée :
    fichier Excel produit par generateur_planning.py

Sortie :
    fichier Excel d'analyse, avec :
      - Synthèse
      - une feuille par groupe présent dans le planning

L'analyse est indépendante du générateur :
le programme lit le planning Excel et vérifie a posteriori
les propriétés du planning réellement produit.
L'alternance des matières est déduite du planning lui-même et sa constance
sur toutes les semaines présentes dans le planning est vérifiée sans modèle d'alternance prédéfini.

"""

from pathlib import Path
import re
from collections import defaultdict
from typing import Dict, List, Tuple

from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


# ============================================================
# CONFIGURATION
# ============================================================

GROUPES: List[int] = []
SEMAINES: List[int] = []
NOMBRE_GROUPES = 0
NOMBRE_SEMAINES = 0

# Les matières sont déduites du planning produit, dans l’ordre de première apparition.
MATIERES: List[str] = []
MATIERE_RANG: Dict[str, int] = {}

DUREE_COLLE_MINUTES = 60
BATTEMENT_MINIMUM_MINUTES = 15

FICHIER_ENTREE = "output.xlsx"
FICHIER_SORTIE = "analyse.xlsx"
FICHIER_CONFIGURATION = "input.xlsx"
CONTRAINTES_HORAIRES: Dict[int, List[Tuple[str, int, int]]] = {}



# ============================================================
# OUTILS
# ============================================================

JOURS_ORDRE = {
    "Lundi": 0,
    "Mardi": 1,
    "Mercredi": 2,
    "Jeudi": 3,
    "Vendredi": 4,
}


def heure_en_minutes(heure: str) -> int:
    h, m = str(heure).split(":")
    return int(h) * 60 + int(m)


def normaliser_heure(valeur) -> str:
    if valeur is None:
        return ""

    if hasattr(valeur, "strftime"):
        return valeur.strftime("%H:%M")

    texte = str(valeur).strip().lower()
    if re.fullmatch(r"\d{1,2}h\d{0,2}", texte):
        texte = texte.replace("h", ":")
        if texte.endswith(":"):
            texte += "00"

    # Excel peut parfois fournir 8:30 au lieu de 08:30.
    morceaux = texte.split(":")
    if len(morceaux) == 2:
        try:
            return f"{int(morceaux[0]):02d}:{int(morceaux[1]):02d}"
        except ValueError:
            pass

    return texte


def nettoyer_groupe(valeur):
    if valeur is None or valeur == "":
        return None

    try:
        return int(valeur)
    except (ValueError, TypeError):
        texte = str(valeur).strip()
        if texte.lower().startswith("groupe"):
            try:
                return int(texte.split()[-1])
            except ValueError:
                return None

    return None


# ============================================================
# LECTURE DU PLANNING
# ============================================================

def lire_planning(fichier: str):
    global GROUPES, SEMAINES, NOMBRE_GROUPES, NOMBRE_SEMAINES

    chemin = Path(fichier)

    if not chemin.exists():
        raise FileNotFoundError(
            f"Fichier Excel introuvable : {chemin.resolve()}"
        )

    wb = load_workbook(chemin, data_only=True)

    if "Planning" not in wb.sheetnames:
        raise ValueError(
            "Le fichier Excel doit contenir une feuille 'Planning'."
        )

    ws = wb["Planning"]

    entetes = {
        ws.cell(1, col).value: col
        for col in range(1, ws.max_column + 1)
    }

    colonnes_obligatoires = [
        "Matière",
        "Colleur",
        "Jour",
        "Heure",
    ]

    for colonne in colonnes_obligatoires:
        if colonne not in entetes:
            raise ValueError(
                f"Colonne obligatoire absente de la feuille Planning : "
                f"'{colonne}'."
            )

    # Les semaines sont déduites des en-têtes réellement présents.
    # Elles doivent être Semaine 1, Semaine 2, ..., Semaine N, sans trou.
    colonnes_semaines = {}
    for nom, col in entetes.items():
        if isinstance(nom, str):
            match = __import__("re").fullmatch(r"\s*Semaine\s+(\d+)\s*", nom)
            if match:
                colonnes_semaines[int(match.group(1))] = col

    if not colonnes_semaines:
        raise ValueError("Aucune colonne de semaine trouvée dans la feuille Planning.")

    semaines = sorted(colonnes_semaines)
    if semaines != list(range(1, len(semaines) + 1)):
        raise ValueError(
            "Les colonnes de semaines de la feuille Planning doivent être "
            "Semaine 1, Semaine 2, ..., sans trou."
        )

    SEMAINES = semaines

    planning = []

    for row in range(2, ws.max_row + 1):
        matiere = ws.cell(row, entetes["Matière"]).value
        colleur = ws.cell(row, entetes["Colleur"]).value
        jour = ws.cell(row, entetes["Jour"]).value
        heure = normaliser_heure(
            ws.cell(row, entetes["Heure"]).value
        )

        if not matiere or not jour or not heure:
            continue

        for semaine, col in colonnes_semaines.items():
            groupe = nettoyer_groupe(ws.cell(row, col).value)

            if groupe is None:
                continue

            planning.append({
                "groupe": groupe,
                "semaine": semaine,
                "matiere": str(matiere).strip(),
                "colleur": (
                    str(colleur).strip()
                    if colleur is not None
                    else ""
                ),
                "jour": str(jour).strip(),
                "heure": heure,
                "minutes": heure_en_minutes(heure),
            })

    GROUPES = sorted({x["groupe"] for x in planning})
    NOMBRE_GROUPES = len(GROUPES)
    NOMBRE_SEMAINES = len(SEMAINES)

    if not GROUPES:
        raise ValueError("Aucun groupe trouvé dans la feuille Planning.")

    # Les matières sont également déduites du planning, sans liste prédéfinie.
    MATIERES.clear()
    for ligne in planning:
        matiere = ligne["matiere"]
        if matiere not in MATIERES:
            MATIERES.append(matiere)
    MATIERE_RANG.clear()
    MATIERE_RANG.update({matiere: rang for rang, matiere in enumerate(MATIERES)})

    return planning


def charger_contraintes_horaires(fichier: str = FICHIER_CONFIGURATION) -> None:
    """Lit les contraintes horaires du fichier input.xlsx si la feuille existe."""
    CONTRAINTES_HORAIRES.clear()
    chemin = Path(fichier)
    if not chemin.exists():
        return

    wb = load_workbook(chemin, data_only=True)
    if "Contraintes horaires" not in wb.sheetnames:
        return

    ws = wb["Contraintes horaires"]
    for ligne in range(2, ws.max_row + 1):
        valeurs = [ws.cell(ligne, col).value for col in range(1, 5)]
        if all(v is None or str(v).strip() == "" for v in valeurs):
            continue
        groupe, jour, debut, fin = valeurs
        try:
            groupe = int(groupe)
        except (TypeError, ValueError):
            continue
        if jour is None:
            continue
        jour = str(jour).strip()
        try:
            debut_min = 0 if debut is None or str(debut).strip() == "" else heure_en_minutes(normaliser_heure(debut))
            fin_min = 1439 if fin is None or str(fin).strip() == "" else heure_en_minutes(normaliser_heure(fin))
        except (TypeError, ValueError):
            continue
        if debut_min < fin_min:
            CONTRAINTES_HORAIRES.setdefault(groupe, []).append((jour, debut_min, fin_min))


def contrainte_horaire_violée(ligne: dict) -> bool:
    """Vrai si une colle du planning recouvre une plage interdite."""
    debut_colle = ligne["minutes"]
    fin_colle = debut_colle + DUREE_COLLE_MINUTES
    for jour, debut, fin in CONTRAINTES_HORAIRES.get(ligne["groupe"], []):
        if ligne["jour"] != jour:
            continue
        if max(debut_colle, debut) < min(fin_colle, fin):
            return True
    return False


# ============================================================
# ANALYSE
# ============================================================

def inferer_periode_cycle(lignes_groupe: List[dict]) -> int:
    """Infère la plus petite période de répétition des duos de matières."""
    signatures = {}
    for semaine in SEMAINES:
        matieres = sorted(
            {x["matiere"] for x in lignes_groupe if x["semaine"] == semaine},
            key=lambda m: MATIERE_RANG.get(m, 999),
        )
        signatures[semaine] = tuple(matieres)

    n = len(SEMAINES)
    for periode in range(1, n + 1):
        if all(
            signatures[SEMAINES[i]] == signatures[SEMAINES[i - periode]]
            for i in range(periode, n)
        ):
            return periode
    return n


def analyser_groupe(groupe: int, planning: List[dict]) -> dict:
    lignes_groupe = [
        x for x in planning
        if x["groupe"] == groupe
    ]

    # --------------------------------------------------------
    # 1. Alternance constatée et vérification de sa constance
    # --------------------------------------------------------

    alternance_constatee = []
    periode_cycle = inferer_periode_cycle(lignes_groupe)

    for type_cycle in range(periode_cycle):
        semaines = [
            s for s in SEMAINES
            if (s - 1) % periode_cycle == type_cycle
        ]

        # On prend le premier cycle comme référence pour l'affichage,
        # puis on vérifie chaque occurrence du type.
        lignes_reference = [
            x for x in lignes_groupe
            if x["semaine"] == semaines[0]
        ]

        matieres_reference = sorted(
            {x["matiere"] for x in lignes_reference},
            key=lambda m: MATIERE_RANG.get(m, 999),
        )

        # La première occurrence de chaque position du cycle sert de référence.
        # Aucune alternance "attendue" n'est définie dans le programme.
        occurrences_correctes = 0
        details_erreurs = []

        for semaine in semaines:
            matieres = sorted(
                {x["matiere"] for x in lignes_groupe
                 if x["semaine"] == semaine},
                key=lambda m: MATIERE_RANG.get(m, 999),
            )

            if matieres == matieres_reference:
                occurrences_correctes += 1
            else:
                details_erreurs.append(
                    f"S{semaine}: {', '.join(matieres) if matieres else 'aucune'}"
                )

        alternance_constatee.append({
            "cycle": type_cycle + 1,
            "semaines": ", ".join(str(s) for s in semaines),
            "periode_cycle": periode_cycle,
            "constatee": " + ".join(matieres_reference),
            "occurrences_correctes": occurrences_correctes,
            "total_occurrences": len(semaines),
            "erreurs": "; ".join(details_erreurs),
        })

    # --------------------------------------------------------
    # 2. Deux colles le même jour
    # --------------------------------------------------------

    deux_meme_jour = []

    for semaine in SEMAINES:
        lignes_semaine = [
            x for x in lignes_groupe
            if x["semaine"] == semaine
        ]

        par_jour = defaultdict(list)

        for ligne in lignes_semaine:
            par_jour[ligne["jour"]].append(ligne)

        jours_problematiques = []

        for jour, lignes in par_jour.items():
            if len(lignes) >= 2:
                heures = sorted(
                    x["heure"] for x in lignes
                )
                jours_problematiques.append(
                    f"{jour} ({', '.join(heures)})"
                )

        if jours_problematiques:
            deux_meme_jour.append(
                f"S{semaine} : " + " ; ".join(jours_problematiques)
            )

    # --------------------------------------------------------
    # 3. Enchaînements sans battement
    # --------------------------------------------------------
    # Ici, on considère qu'il y a un problème si la deuxième
    # colle commence avant la fin de la première + 15 minutes.
    # Ainsi 16h -> 17h est signalé.
    # --------------------------------------------------------

    enchainements = []

    for semaine in SEMAINES:
        lignes = [
            x for x in lignes_groupe
            if x["semaine"] == semaine
        ]

        par_jour = defaultdict(list)

        for ligne in lignes:
            par_jour[ligne["jour"]].append(ligne)

        for jour, journees in par_jour.items():
            journees = sorted(
                journees,
                key=lambda x: x["minutes"]
            )

            for a, b in zip(journees, journees[1:]):
                fin_a = (
                    a["minutes"]
                    + DUREE_COLLE_MINUTES
                    + BATTEMENT_MINIMUM_MINUTES
                )

                if b["minutes"] < fin_a:
                    enchainements.append(
                        f"S{semaine} : {jour} "
                        f"{a['heure']} → {b['heure']}"
                    )

    # --------------------------------------------------------
    # 4. Roulement des colleur par matière
    # --------------------------------------------------------

    roulement = []

    for matiere in MATIERES:
        lignes_matiere = [
            x for x in lignes_groupe
            if x["matiere"] == matiere
        ]

        if not lignes_matiere:
            continue

        comptes = defaultdict(int)

        for ligne in lignes_matiere:
            colleur = ligne["colleur"] or "(colleur non renseigné)"
            comptes[colleur] += 1

        total = len(lignes_matiere)

        colleurs = sorted(
            comptes,
            key=lambda p: p.lower()
        )

        for colleur in colleurs:
            nombre = comptes[colleur]
            proportion = 100 * nombre / total

            roulement.append({
                "matiere": matiere,
                "colleur": colleur,
                "nombre": nombre,
                "total": total,
                "proportion": proportion,
            })

    # --------------------------------------------------------
    # 5. Nombre total de semaines avec exactement 2 colles
    # --------------------------------------------------------

    semaines_avec_2 = 0
    semaines_avec_autre_nombre = []

    for semaine in SEMAINES:
        nombre = sum(
            1
            for x in lignes_groupe
            if x["semaine"] == semaine
        )

        if nombre == 2:
            semaines_avec_2 += 1
        else:
            semaines_avec_autre_nombre.append(
                f"S{semaine}: {nombre}"
            )

    contraintes_horaires = [
        f"S{x['semaine']} : {x['jour']} {x['heure']} — {x['matiere']}"
        for x in lignes_groupe
        if contrainte_horaire_violée(x)
    ]

    return {
        "groupe": groupe,
        "periode_cycle": periode_cycle,
        "alternance": alternance_constatee,
        "deux_meme_jour": deux_meme_jour,
        "enchainements": enchainements,
        "roulement": roulement,
        "semaines_avec_2": semaines_avec_2,
        "semaines_avec_autre_nombre": semaines_avec_autre_nombre,
        "contraintes_horaires": contraintes_horaires,
    }


# ============================================================
# EXPORT EXCEL
# ============================================================

BLEU = "1F4E78"
BLEU_CLAIR = "D9EAF7"
GRIS = "E7E6E6"
VERT_CLAIR = "E2F0D9"
ROUGE_CLAIR = "FCE4D6"


def appliquer_entete(ws, ligne=1):
    for cell in ws[ligne]:
        if cell.value is not None:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor=BLEU)
            cell.alignment = Alignment(
                horizontal="center",
                vertical="center",
                wrap_text=True,
            )

    ws.row_dimensions[ligne].height = 30


def ajuster_largeurs(ws, largeurs: Dict[str, float]):
    for colonne, largeur in largeurs.items():
        ws.column_dimensions[colonne].width = largeur


def exporter_analyse(resultats: Dict[int, dict], fichier: str) -> Path:
    chemin = Path(fichier)

    wb = Workbook()
    ws = wb.active
    ws.title = "Synthèse"

    # --------------------------------------------------------
    # Synthèse générale
    # --------------------------------------------------------

    ws.append([
        "Groupe",
        "Alternance",
        "Deux colles même jour",
        "Semaines concernées",
        "Enchaînements sans battement",
        "Semaines concernées",
        "Semaines avec exactement 2 colles",
        "Contraintes horaires violées",
        "Semaines concernées",
    ])

    for groupe in GROUPES:
        r = resultats[groupe]

        alternance_ok = all(
            x["occurrences_correctes"] == x["total_occurrences"]
            for x in r["alternance"]
        )

        semaines_jour = ", ".join(
            str(item).split(" :")[0].replace("S", "")
            for item in r["deux_meme_jour"]
        )

        semaines_enchainement = ", ".join(
            str(item).split(" :")[0].replace("S", "")
            for item in r["enchainements"]
        )

        ws.append([
            groupe,
            "OK" if alternance_ok else "ERREUR",
            len(r["deux_meme_jour"]),
            semaines_jour,
            len(r["enchainements"]),
            semaines_enchainement,
            r["semaines_avec_2"],
            len(r["contraintes_horaires"]),
            ", ".join(
                str(item).split(" :")[0].replace("S", "")
                for item in r["contraintes_horaires"]
            ),
        ])

    appliquer_entete(ws)

    # Centrage de toutes les cellules de la feuille Synthèse.
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment = Alignment(
                horizontal="center",
                vertical="center",
                wrap_text=True,
            )

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    ajuster_largeurs(ws, {
        "A": 10,
        "B": 14,
        "C": 24,
        "D": 28,
        "E": 28,
        "F": 30,
        "G": 28,
        "H": 24,
        "I": 28,
    })

    # --------------------------------------------------------
    # Une feuille par groupe
    # --------------------------------------------------------

    for groupe in GROUPES:
        r = resultats[groupe]

        wg = wb.create_sheet(f"Groupe {groupe}")

        wg["A1"] = f"ANALYSE — GROUPE {groupe}"
        wg["A1"].font = Font(
            bold=True,
            size=16,
            color="FFFFFF",
        )
        wg["A1"].fill = PatternFill("solid", fgColor=BLEU)
        wg.merge_cells("A1:E1")
        wg["A1"].alignment = Alignment(
            horizontal="center",
            vertical="center",
        )
        wg.row_dimensions[1].height = 32

        # ----------------------------------------------------
        # Alternance
        # ----------------------------------------------------

        wg["A3"] = "1. Alternance des matières"
        wg["A3"].font = Font(bold=True, size=13)
        wg.row_dimensions[3].height = 24
        wg["A3"].alignment = Alignment(vertical="center", wrap_text=False)

        wg.append([
            "Cycle",
            "Semaines",
            "Alternance constatée",
            "Constance",
            "Détail des écarts",
        ])

        ligne = wg.max_row

        for item in r["alternance"]:
            wg.append([
                f"Cycle {item['cycle']}",
                item["semaines"],
                item["constatee"],
                (
                    "OK"
                    if item["occurrences_correctes"] == item["total_occurrences"]
                    else "ERREUR"
                ),
                item["erreurs"],
            ])

        appliquer_entete(wg, ligne)

        # ----------------------------------------------------
        # Deux colles le même jour
        # ----------------------------------------------------

        ligne = wg.max_row + 2
        wg.cell(ligne, 1).value = "2. Deux colles le même jour"
        wg.cell(ligne, 1).font = Font(bold=True, size=13)
        wg.row_dimensions[ligne].height = 24
        wg.cell(ligne, 1).alignment = Alignment(vertical="center", wrap_text=False)

        ligne += 1
        wg.cell(ligne, 1).value = "Nombre de semaines"
        wg.cell(ligne, 2).value = len(r["deux_meme_jour"])

        ligne += 1
        wg.cell(ligne, 1).value = "Détail"

        ligne += 1
        if r["deux_meme_jour"]:
            for item in r["deux_meme_jour"]:
                wg.cell(ligne, 1).value = item
                ligne += 1
        else:
            wg.cell(ligne, 1).value = "Aucune"

        # ----------------------------------------------------
        # Enchaînements
        # ----------------------------------------------------

        ligne += 1
        wg.cell(ligne, 1).value = "3. Enchaînements sans battement"
        wg.cell(ligne, 1).font = Font(bold=True, size=13)
        wg.row_dimensions[ligne].height = 24
        wg.cell(ligne, 1).alignment = Alignment(vertical="center", wrap_text=False)

        ligne += 1
        wg.cell(ligne, 1).value = "Nombre de semaines"
        wg.cell(ligne, 2).value = len(r["enchainements"])

        ligne += 1
        wg.cell(ligne, 1).value = "Détail"

        ligne += 1
        if r["enchainements"]:
            for item in r["enchainements"]:
                wg.cell(ligne, 1).value = item
                ligne += 1
        else:
            wg.cell(ligne, 1).value = "Aucun"

        # ----------------------------------------------------
        # Nombre de colles
        # ----------------------------------------------------

        ligne += 1
        wg.cell(ligne, 1).value = "4. Nombre de colles par semaine"
        wg.cell(ligne, 1).font = Font(bold=True, size=13)
        wg.row_dimensions[ligne].height = 24
        wg.cell(ligne, 1).alignment = Alignment(vertical="center", wrap_text=False)

        ligne += 1
        wg.cell(ligne, 1).value = "Semaines avec exactement 2 colles"
        wg.cell(ligne, 2).value = r["semaines_avec_2"]

        ligne += 1
        wg.cell(ligne, 1).value = "Semaines avec un autre nombre"
        wg.cell(ligne, 2).value = (
            ", ".join(r["semaines_avec_autre_nombre"])
            if r["semaines_avec_autre_nombre"]
            else "Aucune"
        )

        # ----------------------------------------------------
        # Contraintes horaires
        # ----------------------------------------------------

        ligne += 2
        wg.cell(ligne, 1).value = "5. Contraintes horaires"
        wg.cell(ligne, 1).font = Font(bold=True, size=13)
        wg.row_dimensions[ligne].height = 24
        wg.cell(ligne, 1).alignment = Alignment(vertical="center", wrap_text=False)

        ligne += 1
        wg.cell(ligne, 1).value = "Nombre de violations"
        wg.cell(ligne, 2).value = len(r["contraintes_horaires"])

        ligne += 1
        wg.cell(ligne, 1).value = "Détail"
        ligne += 1
        if r["contraintes_horaires"]:
            for item in r["contraintes_horaires"]:
                wg.cell(ligne, 1).value = item
                ligne += 1
        else:
            wg.cell(ligne, 1).value = "Aucune"

        # ----------------------------------------------------
        # Roulement des colleurs
        # ----------------------------------------------------

        ligne += 2
        wg.cell(ligne, 1).value = "6. Roulement des colleurs"
        wg.cell(ligne, 1).font = Font(bold=True, size=13)
        wg.row_dimensions[ligne].height = 24
        wg.cell(ligne, 1).alignment = Alignment(vertical="center", wrap_text=False)

        ligne += 1
        debut_table_prof = ligne

        wg.cell(ligne, 1).value = "Matière"
        wg.cell(ligne, 2).value = "Colleur"
        wg.cell(ligne, 3).value = "Nombre de colles"
        wg.cell(ligne, 4).value = "Total matière"
        wg.cell(ligne, 5).value = "Proportion"

        appliquer_entete(wg, ligne)

        for item in r["roulement"]:
            ligne += 1
            wg.cell(ligne, 1).value = item["matiere"]
            wg.cell(ligne, 2).value = item["colleur"]
            wg.cell(ligne, 3).value = item["nombre"]
            wg.cell(ligne, 4).value = item["total"]
            wg.cell(ligne, 5).value = item["proportion"] / 100
            wg.cell(ligne, 5).number_format = "0.0%"

        # Mise en forme générale.
        for row in wg.iter_rows():
            for cell in row:
                cell.alignment = Alignment(
                    vertical="center",
                    wrap_text=True,
                )

        # Les titres de section doivent pouvoir déborder horizontalement
        # dans les cellules voisines lorsqu'elles sont vides.
        # Cela évite que le texte soit tronqué sans devoir élargir
        # manuellement la colonne A.
        titres_sections = {
            "1. Alternance des matières",
            "2. Deux colles le même jour",
            "3. Enchaînements sans battement",
            "4. Nombre de colles par semaine",
            "6. Roulement des colleurs",
        }
        for row in wg.iter_rows():
            for cell in row:
                if cell.value in titres_sections:
                    cell.alignment = Alignment(
                        vertical="center",
                        wrap_text=False,
                        shrink_to_fit=False,
                    )

        wg.freeze_panes = "A4"

        ajuster_largeurs(wg, {
            "A": 28,
            "B": 24,
            "C": 22,
            "D": 18,
            "E": 45,
        })

    wb.save(chemin)
    return chemin


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    import sys

    fichier_entree = (
        sys.argv[1]
        if len(sys.argv) > 1
        else FICHIER_ENTREE
    )

    fichier_sortie = (
        sys.argv[2]
        if len(sys.argv) > 2
        else FICHIER_SORTIE
    )

    print(f"Lecture du planning : {fichier_entree}")
    planning = lire_planning(fichier_entree)
    charger_contraintes_horaires()

    if not planning:
        raise RuntimeError(
            "Aucune colle n'a été trouvée dans la feuille Planning."
        )

    print(f"Analyse de {NOMBRE_GROUPES} groupe(s) sur {NOMBRE_SEMAINES} semaine(s)...")
    if CONTRAINTES_HORAIRES:
        print(f"Vérification de {sum(len(v) for v in CONTRAINTES_HORAIRES.values())} contrainte(s) horaire(s)...")

    resultats = {}

    for groupe in GROUPES:
        resultats[groupe] = analyser_groupe(
            groupe,
            planning,
        )

    print(f"Export de l'analyse : {fichier_sortie}")
    chemin = exporter_analyse(
        resultats,
        fichier_sortie,
    )

    print()
    print("Analyse terminée avec succès.")
    print(f"Fichier : {chemin.resolve()}")


if __name__ == "__main__":
    main()
